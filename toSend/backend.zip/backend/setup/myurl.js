module.exports = {
  mongoURL: "mongodb+srv://vivek:vivek123@cluster0.p0lsn.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
  secret: "mystrongsecret", 

  
};
