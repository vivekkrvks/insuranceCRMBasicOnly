module.exports = {

    //cloudinary
      //Category default
      defaultPoster:"https://res.cloudinary.com/qualifier/image/upload/v1588942774/Default/Qualifier.co.in_1_ejysvh.webp",
      defaultLogo: "https://res.cloudinary.com/qualifier/image/upload/v1580075035/Important/Quiztones_SVG_logo_ycauba.png",
      bankSvg:"https://res.cloudinary.com/qualifier/image/upload/v1577167616/bank-po_xvajlk.svg",
      userImage: "https://vetdeniz.com/wp-content/uploads/2017/10/default-user.jpg",
      endScreen:"https://res.cloudinary.com/qualifier/image/upload/v1577619570/Important/rat_fynigu.jpg"
      
};
  